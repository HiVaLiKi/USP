<?php
session_start();

// If the user is not logged in, redirect them to the login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PINI Inventory</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header class="topbar">
        <div class="logo">
            <span>🧭 PINI</span>
        </div>
        
        <div class="search-bar">
            <input type="text" placeholder="Search inventory...">
        </div>

        <div class="user-menu">
            <span>👤 Admin</span>
            <span class="notification-bell">🔔</span>
        </div>
    </header>

    <div class="workspace">
        
        <nav class="sidebar">
            <ul>
                <li class="active"><a href="index.php">Dashboard</a></li>
                <li><a href="#">Inventory</a></li>
                <li><a href="#">Groups</a></li>
                <li><a href="#">Items</a></li>
                <li><a href="#">Settings</a></li>
            </ul>
        </nav>

        <main class="content">
            <h1>Dashboard</h1>
            <p>This is your main content area. When we build the charts and tables, they will drop right in here.</p>
        </main>

    </div>

</body>
</html>